import torch
import torch.nn as nn
import torchvision.models as models
from ConfigSpace import EqualsCondition
from ConfigSpace import EqualsCondition, UniformFloatHyperparameter, CategoricalHyperparameter, Constant, \
    UniformIntegerHyperparameter
from skorch.callbacks import LRScheduler
from torch.optim import Adam, AdamW

from .skorch_base import SkorchBaseModel
from .unet import UNET_Model

import math

class MLP(nn.Module):

    def __init__(self, metadata, num_features, num_classes, architecture):
        super(MLP, self).__init__()
        self.metadata = metadata
        architecture = [num_features] + architecture + [num_classes]
        print("initializing mlp with architecture", architecture)
        layers = [nn.Linear(architecture[i], architecture[i+1]) for i in range(len(architecture)-1)]
        for i in range(len(layers)-1,0,-1):
            layers.insert(i,nn.ReLU())
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        x = x.reshape((x.shape[0], -1))
        x = self.net.forward(x)
        return x


class MLP_Model(SkorchBaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        if self.cfg['optimizer'] == 'Adam':
            self.skorch_kwargs['optimizer'] = Adam
        elif self.cfg['optimizer'] == 'AdamW':
            self.skorch_kwargs['optimizer'] = AdamW
            self.skorch_kwargs['optimizer__weight_decay'] = self.cfg['weight_decay']

        if self.cfg['lr_scheduler']:
            self.callbacks.append(
                self.callbacks.append(LRScheduler(policy='CosineAnnealingLR', T_max=self.cfg['max_epochs'])))

        # overwrite timeout limit
        self.callbacks[0].time_budget = min(self.callbacks[0].time_budget, 600)
        self.time_budget = self.callbacks[0].time_budget

        self.model = self.model_class(
            MLP,
            module__metadata=metadata,
            module__architecture=self.cfg['architecture'] if 'architecture' in self.cfg else [256, 128],
            module__num_features=math.prod(self.input_shape),
            module__num_classes=math.prod(self.output_shape),
            max_epochs=self.cfg['max_epochs'],
            lr=self.cfg['lr'],
            callbacks=self.callbacks,
            **self.skorch_kwargs
        )

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="mlp")
        lr = UniformFloatHyperparameter(
            name="lr", lower=1e-5, upper=1e-1, default_value=1e-4, log=True
        )
        optimizer = CategoricalHyperparameter(
            name="optimizer", choices=['Adam', 'AdamW'], default_value='AdamW'
        )
        lr_scheduler = CategoricalHyperparameter(
            name="lr_scheduler", choices=[True, False], default_value=False
        )
        weight_decay = UniformFloatHyperparameter(
            name="weight_decay", lower=1e-7, upper=1e-1, default_value=0.03, log=True
        )
        max_epochs = UniformIntegerHyperparameter(
            name="max_epochs", lower=1, upper=300, default_value=300, log=False
        )
        cs.add_hyperparameters(
            [name, lr, max_epochs, optimizer, lr_scheduler, weight_decay])
        weight_decay_condition = EqualsCondition(weight_decay, optimizer, 'AdamW')
        cs.add_conditions([weight_decay_condition])
        return cs

    @classmethod
    def is_applicable(cls, metadata):
        return metadata.input_shape.width*metadata.input_shape.height*metadata.input_shape.max_sequence_len*metadata.input_shape.channels < 1024 
