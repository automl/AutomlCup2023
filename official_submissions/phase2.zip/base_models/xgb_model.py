import time

import numpy as np
import xgboost as xgb
from ConfigSpace import UniformFloatHyperparameter, UniformIntegerHyperparameter, Constant
from xgboost.callback import TrainingCallback

from .base_model import BaseModel


class TimeOut(TrainingCallback):
    def __init__(self, time_budget):
        self.time_budget = time_budget
        self.begin_time = time.monotonic()

    def after_iteration(self, model, epoch, evals_log):
        stop_run = False
        if time.monotonic() > self.begin_time + self.time_budget:
            print(
                f"Time budget of {self.time_budget:.1f}s exceeded by {time.monotonic() - (self.begin_time + self.time_budget):.1f}s")
            stop_run = True
        return stop_run


class XGB_Model(BaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        self.model = (
            xgb.XGBClassifier() if self.is_classification else xgb.XGBRegressor()) if input_cfg is None else self.init_config(
            self.cfg)
        self.model.set_params(callbacks=[TimeOut(self.time_budget)])

    def init_config(self, cfg):
        model_params = {
            "objective": "binary:logistic" if self.is_classification else "reg:absoluteerror",
            # "max_depth": 3,
            # "early_stopping_rounds": 5,
            "n_jobs": 10,
            "gpu_id": 0,
            "tree_method": "gpu_hist",
            "sampling_method": "gradient_based",
            **cfg,
        }
        return xgb.XGBClassifier(**model_params) if self.is_classification else xgb.XGBRegressor(**model_params)

    def fit(self, X: np.ndarray, y: np.ndarray, X_unlabeled: np.ndarray = None, y_unlabeled: np.ndarray = None, X_val: np.ndarray = None, y_val: np.ndarray = None):
        # TODO: provide validation set to xgb
        X = X.reshape((X.shape[0], -1))
        X_val = X_val.reshape((X_val.shape[0], -1))
        super().fit(X, y, X_unlabeled, y_unlabeled, X_val, y_val)

    def predict(self, X: np.ndarray):
        X = X.reshape((X.shape[0], -1))
        y = super().predict(X)
        return y

    def predict_proba(self, X: np.ndarray):
        X = X.reshape((X.shape[0], -1))
        y = super().predict_proba(X)
        return y

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="xgb")
        # early_stopping_rounds = UniformIntegerHyperparameter(
        #     name="early_stopping_rounds", lower=3, upper=15, default_value=5, log=False
        # )
        max_depth = UniformIntegerHyperparameter(
            name="max_depth", lower=3, upper=6, default_value=3, log=False
        )
        l2_reg = UniformFloatHyperparameter(
            name="lambda", lower=1e-10, upper=1., default_value=.3, log=True
        )
        eta = UniformFloatHyperparameter(
            name="eta", lower=1e-2, upper=1., default_value=.3, log=True
        )
        sub_sample = UniformFloatHyperparameter(
            name="subsample", lower=0.1, upper=1., default_value=0.9, log=False
        )
        cs.add_hyperparameters([name, l2_reg, eta, sub_sample, max_depth])
        return cs
    
    @classmethod
    def is_applicable(cls, metadata):
        return metadata.input_dimension == 0 
