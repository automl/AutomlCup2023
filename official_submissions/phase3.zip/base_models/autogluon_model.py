from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from ConfigSpace import Constant, Categorical
from autogluon.tabular import TabularPredictor

from .base_model import BaseModel
from .multilabel_autogluon import MultilabelPredictor

from .model_utils import is_multi_label
from .multires_conv_model import MultiResConvModel

class AutoGluonWrapper:
    def __init__(self, metadata, is_multi_label, cfg):
        self.cfg = cfg
        self.metadata = metadata
        self.time_budget = metadata.training_limit_sec
        self.is_multi_label = is_multi_label
        save_path = Path(__file__).parent / 'autogluon_output' / str(int(datetime.now().timestamp()))
        save_path.mkdir(exist_ok=True, parents=True)
        if is_multi_label:
            labels = [f'label_{i}' for i in range(np.prod(metadata.output_shape))]
            predictor_kwargs = {}
            if metadata.evaluation_metric.value == 'bce':
                from autogluon.core.metrics import make_scorer
                from .autogluon_output.autogluon_metrics import bce
                bce_scorer = make_scorer(name='bce',
                                                score_func=bce,
                                                optimum=0,
                                                greater_is_better=False,
                                                needs_threshold=True)
                predictor_kwargs['eval_metrics'] = [bce_scorer] * int(np.prod(metadata.output_shape))
            self.autogluon_predictor = MultilabelPredictor(labels=labels, path=str(save_path), **predictor_kwargs)
        else:
            self.autogluon_predictor = TabularPredictor("label", path=str(save_path))

    # TODO: support unlabeled data, need to overwrite fit of Autogluon_Model to pass the unlabeled data
    def fit(self, X: np.ndarray, y: np.ndarray, X_unlabeled: np.ndarray = None, y_unlabeled: np.ndarray = None):
        X = X.reshape((X.shape[0], -1))
        df = pd.DataFrame(X)
        time_limit = self.time_budget
        if self.is_multi_label:
            y = y.reshape((y.shape[0], -1))
            for i in range(y.shape[1]):
                df[f'label_{i}'] = y[:, i]
            time_limit = int(time_limit / y.shape[1])
        else:
            assert len(y.shape) == 1
            df['label'] = y
        #  num_bag_folds=5, num_bag_sets=1, num_stack_levels=3, auto_stack=True,
        self.autogluon_predictor.fit(df,
                                     time_limit=time_limit,
                                     presets=self.cfg['presets'],
                                     )

    def predict(self, X: np.ndarray) -> np.ndarray:
        if self.metadata.evaluation_metric.value == 'bce':
            return self.predict_proba(X)
        X = X.reshape((X.shape[0], -1))
        X = pd.DataFrame(X)
        return self.autogluon_predictor.predict(X).values

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = X.reshape((X.shape[0], -1))
        X = pd.DataFrame(X)

        if self.is_multi_label:
            # only binary
            pred = self.autogluon_predictor.predict_proba(X)
            combined_pred = []
            for i in range(len(pred)):
                combined_pred.append(pred[f'label_{i}'].values[:, 1])
            pred = np.stack(combined_pred, axis=-1)
        else:
            pred = self.autogluon_predictor.predict_proba(X).values
        # is a dict with label_0 etc as key
        return pred


class Autogluon_Model(BaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        self.model = AutoGluonWrapper(metadata, self.is_multi_label, self.cfg)

    def generate_statistics(self, X_test=None, y_test=None):
        if self.is_multi_label:
            return
        if len(y_test.shape) == 2:
            y_test = np.argmax(y_test, axis=1)
        X_test = X_test.reshape((X_test.shape[0], -1))
        df = pd.DataFrame(X_test)
        df['label'] = y_test
        evaluation = self.model.autogluon_predictor.evaluate(df, silent=True)
        leaderboard = self.model.autogluon_predictor.leaderboard(df, silent=True)
        self.run_statistics['evaluation'] = evaluation
        self.run_statistics['leaderboard'] = leaderboard.to_dict()

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="autogluon")
        presets = Categorical(name='presets',
                              items=['medium_quality', 'good_quality', 'high_quality', 'best_quality'],
                              default='medium_quality')
        cs.add_hyperparameters([name, presets])
        return cs

    @classmethod
    def is_applicable(cls, metadata):
        return (metadata.input_shape.height == 1 and metadata.input_shape.width == 1) and (not MultiResConvModel.is_applicable(metadata)) and len(metadata.output_shape) == 1 and ((not is_multi_label(metadata) and metadata.output_type.value == "classification") or metadata.output_shape[0] < 16)
