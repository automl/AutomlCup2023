import numpy as np
import torch
import torch.nn as nn
from ConfigSpace import Constant, UniformFloatHyperparameter, UniformIntegerHyperparameter
from skorch import NeuralNetClassifier, NeuralNetRegressor
from torch.nn.functional import interpolate
from torch.optim import Adam

from .skorch_base import SkorchBaseModel

import math

class DeepSEA(nn.Module):
    def __init__(self, input_shape, output_shape):
        """
        Parameters
        ----------
        sequence_length : int
        n_genomic_features : int
        """
        super(DeepSEA, self).__init__()
        t, c, h, w = input_shape
        if t > 1:
            sequence_length = t
        else:
            sequence_length = h
        if sequence_length < 25:
            sequence_length = 25
        n_features = 1  # input_shape[1]
        n_genomic_features = math.prod(output_shape)
        conv_kernel_size = 8
        pool_kernel_size = 4
        if sequence_length < 200:
            conv_kernel_size = 4
            pool_kernel_size = 2

        self.conv_net = nn.Sequential(
            nn.Conv1d(n_features, 320, kernel_size=conv_kernel_size),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(
                kernel_size=pool_kernel_size, stride=pool_kernel_size),
            nn.Dropout(p=0.2),

            nn.Conv1d(320, 480, kernel_size=conv_kernel_size),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(
                kernel_size=pool_kernel_size, stride=pool_kernel_size),
            nn.Dropout(p=0.2),

            nn.Conv1d(480, 960, kernel_size=conv_kernel_size),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5))

        reduce_by = conv_kernel_size - 1
        pool_kernel_size = float(pool_kernel_size)
        self.n_channels = int(
            np.floor(
                (np.floor(
                    (sequence_length - reduce_by) / pool_kernel_size)
                 - reduce_by) / pool_kernel_size)
            - reduce_by)
        self.classifier = nn.Sequential(
            nn.Linear(960 * self.n_channels, n_genomic_features),
            nn.ReLU(inplace=True),
            nn.Linear(n_genomic_features, n_genomic_features))

    def forward(self, x):
        """Forward propagation of a batch.
        """
        if x.shape[1] == 1:
            x = x.transpose(1, 3)
        x = x.transpose(1, 2)
        x = torch.squeeze(x, 3)
        x = torch.squeeze(x, 3)
        if x.shape[2] < 25:
            x = interpolate(x, 25, mode='linear')
        out = self.conv_net(x)
        reshape_out = out.view(out.size(0), 960 * self.n_channels)
        predict = self.classifier(reshape_out)
        return predict


class DeepSEA_Model(SkorchBaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        self.model = self.model_class(
            DeepSEA,
            optimizer=Adam,
            batch_size=self.cfg['batch_size'],
            module__input_shape=self.input_shape,
            module__output_shape=self.output_shape,
            max_epochs=self.cfg['max_epochs'],
            lr=self.cfg['lr'],
            callbacks=self.callbacks,
            **self.skorch_kwargs,
        )

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="deepsea")
        lr = UniformFloatHyperparameter(
            name="lr", lower=1e-5, upper=1e-2, default_value=1e-3, log=True
        )
        max_epochs = UniformIntegerHyperparameter(
            name="max_epochs", lower=1, upper=80, default_value=10, log=False
        )
        batch_size = UniformIntegerHyperparameter(
            name="batch_size", lower=1, upper=1000, default_value=128, log=False
        )
        cs.add_hyperparameters([name, lr, max_epochs, batch_size])
        return cs
