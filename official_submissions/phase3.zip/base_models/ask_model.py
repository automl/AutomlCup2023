# TODO: check whether we need to reshape X to 2d like in autogluon
import numpy as np
from ConfigSpace import Constant

from .base_model import BaseModel
from autosklearn.classification import AutoSklearnClassifier
from autosklearn.regression import AutoSklearnRegressor
from autosklearn.experimental.askl2 import AutoSklearn2Classifier

class ASK_Model(BaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        memory_limit=32000 # make sure we have 8GB of memory
        if self.is_classification:
            if self.cfg.get('version', 2) == 1:
                self.model = AutoSklearnClassifier(
                    memory_limit=memory_limit,
                    time_left_for_this_task=metadata.training_limit_sec
)
            else:
                self.model = AutoSklearn2Classifier(
                    memory_limit=memory_limit,
                    time_left_for_this_task=metadata.training_limit_sec)
        else:
            self.model = AutoSklearnRegressor(
                memory_limit=memory_limit,
                time_left_for_this_task=metadata.training_limit_sec)


    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="ask")
        cs.add_hyperparameters([name])
        return cs
