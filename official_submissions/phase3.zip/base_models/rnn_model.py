import torch
import torch.nn as nn
from ConfigSpace import Constant, UniformFloatHyperparameter, UniformIntegerHyperparameter
from skorch import NeuralNetClassifier, NeuralNetRegressor
from torch.optim import Adam

from .skorch_base import SkorchBaseModel

import math

class SimpleRNN(nn.Module):
    def __init__(self, input_shape, output_shape):
        super(SimpleRNN, self).__init__()
        channel = 1
        hidden_size = max(2 * channel, 128)
        self.lstm = nn.LSTM(channel, hidden_size, batch_first=True)
        self.gru = nn.GRU(channel, hidden_size, batch_first=True)
        self.rnn = nn.RNN(channel, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size * 3, math.prod(output_shape))

    def forward(self, x):
        x = x.squeeze()
        x = x.reshape(x.shape + (1,))
        _, (hidden_lstm, _) = self.lstm(x)
        _, hidden_gru = self.gru(x)
        _, hidden_rnn = self.rnn(x)

        x = self.fc(torch.cat((hidden_lstm[-1], hidden_gru[-1], hidden_rnn[-1]), dim=-1))
        return x


class RNN_Model(SkorchBaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        self.model = self.model_class(
            SimpleRNN,
            optimizer=Adam,
            batch_size=self.cfg['batch_size'],
            module__input_shape=self.input_shape,
            module__output_shape=self.output_shape,
            max_epochs=self.cfg['max_epochs'],
            lr=self.cfg['lr'],
            callbacks=self.callbacks,
            **self.skorch_kwargs,
        )

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="rnn")
        lr = UniformFloatHyperparameter(
            name="lr", lower=1e-5, upper=1e-2, default_value=1e-3, log=True
        )
        max_epochs = UniformIntegerHyperparameter(
            name="max_epochs", lower=1, upper=80, default_value=10, log=False
        )
        batch_size = UniformIntegerHyperparameter(
            name="batch_size", lower=1, upper=1000, default_value=128, log=False
        )
        cs.add_hyperparameters([name, lr, max_epochs, batch_size])
        return cs
