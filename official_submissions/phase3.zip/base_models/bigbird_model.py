from base_model import BaseModel
from .skorch_base import SkorchBaseModel
import numpy as np
import torch
import torch.nn as nn
from datasets import Dataset
from skorch import NeuralNetClassifier
from skorch.callbacks import EarlyStopping, LRScheduler, WarmRestartLR
from torch.optim import AdamW
from wrn1d import WideResNet1d

from ConfigSpace.configuration_space import ConfigurationSpace
from ConfigSpace.hyperparameters import *
from ConfigSpace import Constant

np.random.seed(1)
torch.manual_seed(1)



class WRN_Model(SkorchBaseModel):
    def __init__(self, input_shape, output_shape, num_classes, cfg = None):
        super().__init__(input_shape, output_shape, num_classes, cfg)
        self.model = NeuralNetClassifier(
            WideResNet1d,
            optimizer=AdamW,
            batch_size=100,
            module__input_shape=self.input_shape,
            module__output_shape=self.output_shape,
            module__num_classes=self.num_classes,
            module__widen_factor=4 if cfg is None else cfg["widen_factor"],
            module__dropRate=0.0 if cfg is None else cfg["dropRate"],
            module__in_channels=1,
            module__depth=16 if cfg is None else cfg["depth"]*6+4,
            max_epochs=30,
            criterion=nn.CrossEntropyLoss(),
            lr=1e-3,
            device=self.device,
            # Shuffle training data on each epoch
            iterator_train__shuffle=True,
            callbacks=self.callbacks,
        )

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="wrn")
        depth = UniformIntegerHyperparameter(
            name="depth", lower=1, upper=4, default_value=2, log=False
        )
        widen_factor = UniformIntegerHyperparameter(
            name="widen_factor", lower=2, upper=6, default_value=4, log=False
        )
        dropRate = UniformFloatHyperparameter(
            name="dropRate", lower=0.0, upper=0.3, default_value=0.0, log=False
        )
        cs.add_hyperparameters([name, depth, widen_factor, dropRate])
        return cs
