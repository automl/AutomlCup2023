# TODO: check whether we need to reshape X to 2d like in autogluon
# TODO: consider using gpu
from ConfigSpace import Constant
from tabpfn import TabPFNClassifier
from tabpfn import TabPFNRegressor

from .base_model import BaseModel


class TabPFN_Model(BaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        if self.is_classification:
            self.model = TabPFNClassifier(device="cpu", N_ensemble_configurations=32)
        else:
            self.model = TabPFNRegressor(device="cpu", N_ensemble_configurations=32)

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="tabpfn")
        cs.add_hyperparameters([name])
        return cs
