import numpy as np
from .base_model import BaseModel
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import KNeighborsRegressor
from ConfigSpace import Constant

class KNN_Model(BaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        if self.is_classification:
            self.model = KNeighborsClassifier()
        else:
            self.model = KNeighborsRegressor()

    def fit(self, X: np.ndarray, y: np.ndarray):
        X = X.reshape((X.shape[0],-1))
        super().fit(X, y)

    def predict(self, X: np.ndarray):
        X = X.reshape((X.shape[0],-1))
        y = super().predict(X)
        return y

    def predict_proba(self, X: np.ndarray):
        X = X.reshape((X.shape[0],-1))
        y = super().predict_proba(X)
        return y

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="knn")
        cs.add_hyperparameters([name])
        return cs
