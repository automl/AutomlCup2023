import numpy as np


def check_binary(column: np.array) -> bool:
    assert len(column.shape) == 1, 'Only takes a single column as input'
    unique_values = np.unique(column)
    is_binary = False
    if len(unique_values) <= 2:
        is_binary = all([value in [0., 1.] for value in unique_values])
    return is_binary


class OrdinalEncoder:

    def __init__(self, variant='strict'):
        self.splits = None
        self.categorical_indices = None
        self.variant = variant

    def fit(self, one_hot_data: np.array):
        max_len = one_hot_data.shape[1]
        one_indices = [np.where(one_hot_data[i] == 1.)[0] for i in range(one_hot_data.shape[0])]
        splits = []
        old_split = 0
        while old_split < max_len:
            first_occurence = [indices[0] for indices in one_indices]  # -np.inf
            if self.variant == 'strict':
                second_occurence = [indices[1] if len(indices) > 1 else np.inf for indices in one_indices]  # np.inf
                new_split = min(max(first_occurence) + 1, min(second_occurence))
                new_split = min(new_split, max_len)  # for last iteration where min(second_occurence) is inf
            else:
                new_split = max(first_occurence) + 1
            splits.append((old_split, new_split))
            old_split = new_split
            # filter values
            one_indices = [indices[indices > old_split] for indices in one_indices]
            one_indices = [indices for indices in one_indices if len(indices) > 0]

            # if last columns just has zeros
            if len(one_indices) == 0 and old_split != max_len:
                splits.append((old_split, max_len))
                old_split = max_len
        self.splits = splits

    def transform(self, one_hot_data: np.array) -> np.array:
        ordinal_data = np.zeros((one_hot_data.shape[0], len(self.splits)))
        one_indices = [np.where(one_hot_data[i] == 1.)[0] for i in range(one_hot_data.shape[0])]
        for column_idx, split in enumerate(self.splits):
            for row_idx, indices in enumerate(one_indices):
                active_class = indices[np.logical_and(indices >= split[0], indices < split[1])]
                if len(active_class) > 0:
                    ordinal_data[row_idx, column_idx] = active_class[0] - split[0] + 1
        return ordinal_data