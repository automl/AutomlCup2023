"""
Reference : https://pytorch.org/vision/main/models/generated/torchvision.models.regnet_y_16gf.html
"""
import math

import torch
import torch.nn as nn
from ConfigSpace.hyperparameters import *
from skorch import NeuralNetClassifier, NeuralNetRegressor
from torch.optim import Adam

from .skorch_base import SkorchBaseModel
import torchvision.models as models
from torchvision.models import RegNet_Y_16GF_Weights

from .unet import UNET_Model

class RegNet(nn.Module):

    def __init__(self, metadata, num_classes, use_pretrained=True):
        super(RegNet, self).__init__()
        self.metadata = metadata
        timeseries = self.metadata.input_shape.max_sequence_len
        channel = self.metadata.input_shape.channels
        self.net = models.regnet_y_16gf(weights=RegNet_Y_16GF_Weights.DEFAULT if use_pretrained else None)
        num_ftrs = self.net.fc.in_features
        self.net.fc = nn.Linear(num_ftrs, num_classes)
        if not (timeseries * channel == 1 or timeseries * channel == 3):
            self.net.stem[0] = nn.Conv2d(timeseries * channel, 32, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)

    def forward(self, x):
        # TODO fix for timeseries > 1 and channel=1 and make sure its correct in all cases 
        if x.shape[2] == 1:
            x = x.repeat(1, 1, 3, 1, 1)
        x = x.reshape((x.shape[0], -1, x.shape[3], x.shape[4]))
        x = self.net.forward(x)
        return x

    def disable_gradients(self, model) -> None:
        """
        Freezes the layers of a model
        Args:
            model: The model with the layers to freeze
        Returns:
            None
        """
        for parameter in model.parameters():
            parameter.requires_grad = False

class RegNet_Model(SkorchBaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        self.model = self.model_class(
            RegNet,
            optimizer=Adam,
            batch_size=self.cfg['batch_size'],
            module__metadata=metadata,
            module__num_classes=math.prod(self.output_shape),
            module__use_pretrained=self.cfg['pretrained'],
            max_epochs=self.cfg['max_epochs'],
            lr=self.cfg['lr'],
            callbacks=self.callbacks,
            **self.skorch_kwargs
        )

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="regnet")
        lr = UniformFloatHyperparameter(
            name="lr", lower=1e-5, upper=1e-2, default_value=1e-3, log=True
        )
        max_epochs = UniformIntegerHyperparameter(
            name="max_epochs", lower=1, upper=300, default_value=30, log=False
        )
        batch_size = UniformIntegerHyperparameter(
            name="batch_size", lower=1, upper=128, default_value=128, log=False
        )
        pretrained = CategoricalHyperparameter(
            name="pretrained", choices=[False, True], default_value=True
        )
        cs.add_hyperparameters([name, lr, max_epochs, batch_size, pretrained])
        return cs

    @classmethod
    def is_applicable(cls, metadata):
        return (metadata.input_shape.width > 1 and metadata.input_shape.height > 1) and metadata.input_shape.max_sequence_len == 1 and (not UNET_Model.is_applicable(metadata))
