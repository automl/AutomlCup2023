import math
import random
import time
from timeit import default_timer as timer

import numpy as np
import torch
from ConfigSpace.hyperparameters import *
from skorch.dataset import Dataset
from skorch.helper import predefined_split
from torch.optim import Adam

from .multires_conv_model import MultiResConvModel
from .skorch_base import SkorchBaseModel
from .unet import UNET_Model
from .wrn1d import WideResNet1d
from .wrn2d import WideResNet2d
from .wrn3d import WideResNet3d


class WRN_Model(SkorchBaseModel):
    def __init__(self, metadata, input_cfg=None, seed=None):
        super().__init__(metadata, input_cfg, seed)
        spacetime_dims = metadata.input_dimension  # np.count_nonzero(np.array(self.input_shape)[[0, 2, 3]] != 1)

        if spacetime_dims <= 1:
            wrn_class = WideResNet1d
        elif spacetime_dims == 2:
            wrn_class = WideResNet2d
        elif spacetime_dims == 3:
            wrn_class = WideResNet3d
        else:
            raise ValueError(f'Uknown input dimension. Given input dimension is {spacetime_dims}')
        # stratify = False
        self.model = self.model_class(
            wrn_class,
            optimizer=Adam,
            batch_size=self.cfg['batch_size'],
            module__input_shape=self.input_shape,
            module__num_classes=math.prod(self.output_shape),
            module__widen_factor=self.cfg["widen_factor"],
            module__dropRate=self.cfg["dropRate"],
            module__in_channels=self.input_shape[1] if spacetime_dims > 0 else 1,
            module__depth=self.cfg["depth"] * 6 + 4,
            max_epochs=self.cfg['max_epochs'],
            lr=self.cfg['lr'],
            callbacks=self.callbacks,
            **self.skorch_kwargs
        )

    def fit(self, X: np.ndarray, y: np.ndarray, X_unlabeled: np.ndarray = None, y_unlabeled: np.ndarray = None,
            X_val: np.ndarray = None, y_val: np.ndarray = None):
        X = X.reshape((-1,) + self.input_shape)
        X_val = X_val.reshape((-1,) + self.input_shape)
        X = X.astype(
            "float32" if self.dtype_input is None else self.dtype_input)  # Todo: some models want int. Maybe save the datatype needed.
        X_val = X_val.astype(
            "float32" if self.dtype_input is None else self.dtype_input)  # Todo: some models want int. Maybe save the datatype needed.
        if X_unlabeled is not None:
            X_unlabeled = X_unlabeled.reshape((-1,) + self.input_shape)
            X_unlabeled = X_unlabeled.astype(
                "float32" if self.dtype_input is None else self.dtype_input)
        if self.is_multi_label or not self.is_classification:
            y = y.astype("float32")
            y_val = y_val.astype("float32")
        self.model.set_params(train_split=predefined_split(Dataset(X_val, y_val)))
        torch.use_deterministic_algorithms(True)
        if self.seed is not None:
            random.seed(self.seed)
            np.random.seed(self.seed)
            torch.manual_seed(self.seed)
            if torch.cuda.is_available():
                torch.backends.cudnn.deterministic = True
                torch.backends.cudnn.benchmark = False
        start = timer()
        print("Start Training", self.__class__.__name__)
        if not self.is_classification and self.output_transform:
            # y_combined = np.concatenate((y, y_unlabeled), axis=0)
            shape = y.shape
            val_shape = y_val.shape
            y = y.reshape(len(y), -1)
            y_val = y_val.reshape(len(y_val), -1)
            if self.use_min_max:
                self.min_max_scaler.fit(y)
                y = self.min_max_scaler.transform(y)
                y_val = self.min_max_scaler.transform(y_val)
                # y_unlabeled = self.min_max_scaler.transform(y_unlabeled)
            else:
                self.standard_scaler.fit(y)
                y = self.standard_scaler.transform(y)
                y_val = self.standard_scaler.transform(y_val)
                # y_unlabeled = self.standard_scaler.transform(y_unlabeled)
            y = y.reshape(shape)
            y_val = y_val.reshape(val_shape)
        if (X_unlabeled is None or len(X_unlabeled) == 0) or (not self.is_classification):
            self.model.fit(X, y)
        else:
            self.model.set_params(max_epochs=1)
            for i in range(self.cfg['max_epochs']):
                if time.monotonic() > self.begin_time + self.time_budget:
                    break
                self.model.partial_fit(X, y)
                if time.monotonic() > self.begin_time + self.time_budget:
                    break
                if i < self.cfg['fixmatch_warmup'] or len(X_unlabeled) == 0:
                    continue
                prob_distributions = self.predict_proba(X_unlabeled)
                labels = np.argmax(prob_distributions, axis=1)
                highest_prob = np.squeeze(np.max(prob_distributions, axis=1), axis=1)
                newly_labeled = highest_prob > self.cfg['fixmatch_threshold']
                if self.is_multi_label or not self.is_classification:
                    labels = labels.astype("float32")
                X_unlabeled, X_newly_labeled = X_unlabeled[~newly_labeled], X_unlabeled[newly_labeled]
                X = np.concatenate((X, X_newly_labeled))
                y = np.concatenate((y, labels[newly_labeled]))

        end = timer()
        self.run_statistics['runtime'] = end - start
        print("Stopped Training", self.__class__.__name__, f"took {self.run_statistics['runtime']:.1f}")

    @classmethod
    def get_config_space(cls):
        cs = super().get_config_space()
        name = Constant(name="model_name", value="wrn")
        depth = UniformIntegerHyperparameter(
            name="depth", lower=1, upper=4, default_value=1, log=False
        )
        widen_factor = UniformIntegerHyperparameter(
            name="widen_factor", lower=2, upper=6, default_value=4, log=False
        )
        dropRate = UniformFloatHyperparameter(
            name="dropRate", lower=0.0, upper=0.3, default_value=0.0, log=False
        )
        fixmatch_warmup = UniformIntegerHyperparameter(
            name="fixmatch_warmup", lower=0, upper=10, default_value=3, log=False
        )
        fixmatch_threshold = UniformFloatHyperparameter(
            name="fixmatch_threshold", lower=0.6, upper=0.99, default_value=0.9, log=False
        )
        lr = UniformFloatHyperparameter(
            name="lr", lower=1e-5, upper=1e-2, default_value=1e-3, log=True
        )
        max_epochs = UniformIntegerHyperparameter(
            name="max_epochs", lower=1, upper=300, default_value=300, log=False
        )
        batch_size = UniformIntegerHyperparameter(
            name="batch_size", lower=1, upper=1000, default_value=128, log=False
        )
        cs.add_hyperparameters(
            [name, depth, widen_factor, dropRate, fixmatch_threshold, fixmatch_warmup, lr, max_epochs, batch_size])
        return cs

    @classmethod
    def is_applicable(cls, metadata):
        return (metadata.input_dimension > 0) and (not UNET_Model.is_applicable(metadata)) and (
            not MultiResConvModel.is_applicable(metadata))
