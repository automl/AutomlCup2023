import numpy as np
from torch import Tensor
from torch.nn.functional import binary_cross_entropy


def bce(y_true, y_pred):
    return binary_cross_entropy(Tensor(np.array(y_true)), Tensor(y_pred), reduction="mean").item()