def get_model(model_str: str, phase: str = 'phase-1'):
    model_str = model_str.lower()
    if model_str == "catboost":
        from .base_models.catboost_model import CatBoost_Model
        model_cls = CatBoost_Model
    elif model_str == "knn":
        from .base_models.knn_model import KNN_Model
        model_cls = KNN_Model
    elif model_str == "ask":
        from .base_models.ask_model import ASK_Model
        model_cls = ASK_Model
    elif model_str == "deepsea":
        from .base_models.deepsea_model import DeepSEA_Model
        model_cls = DeepSEA_Model
    elif model_str == "ntm":
        from .base_models.ntm_model import NTM_Model
        model_cls = NTM_Model
    elif model_str == "rnn":
        from .base_models.rnn_model import RNN_Model
        model_cls = RNN_Model
    elif model_str == "wrn":
        from .base_models.wrn_model import WRN_Model
        model_cls = WRN_Model
    elif model_str == "xgb":
        from .base_models.xgb_model import XGB_Model
        model_cls = XGB_Model
    elif model_str == "autogluon":
        from .base_models.autogluon_model import Autogluon_Model
        model_cls = Autogluon_Model
    elif model_str == "main":
        if phase == 'phase-1':
            from .model1 import Model
            model_cls = Model
        elif phase == 'phase-2':
            from .model2 import Model
            model_cls = Model
        else:
            raise ValueError(f"Phase value {phase} is not supported.")
    else:
        raise ValueError(f"The model name '{model_str}' is unknown. Use a known model name")
    return model_cls


def instantiate_model(model_name: str, metadata, config: dict = None, seed=0):
    def get_model(model_name: str, config: dict = None):
        if model_name == 'ensemble':
            try:
                from base_models.ensemble_model import Ensemble_Model
            except ModuleNotFoundError:
                from models.base_models.ensemble_model import Ensemble_Model
            model = Ensemble_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'ask':
            try:
                from base_models.ask_model import ASK_Model
            except ModuleNotFoundError:
                from models.base_models.ask_model import ASK_Model
            model = ASK_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'autogluon':
            try:
                from base_models.autogluon_model import Autogluon_Model
            except ModuleNotFoundError:
                from models.base_models.autogluon_model import Autogluon_Model
            model = Autogluon_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'wrn':
            try:
                from base_models.wrn_model import WRN_Model
            except ModuleNotFoundError:
                from models.base_models.wrn_model import WRN_Model
            model = WRN_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'rnn':
            try:
                from base_models.rnn_model import RNN_Model
            except ModuleNotFoundError:
                from models.base_models.rnn_model import RNN_Model
            model = RNN_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'deepsea':
            try:
                from base_models.deepsea_model import DeepSEA_Model
            except ModuleNotFoundError:
                from models.base_models.deepsea_model import DeepSEA_Model
            model = DeepSEA_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'knn':
            try:
                from base_models.knn_model import KNN_Model
            except ModuleNotFoundError:
                from models.base_models.knn_model import KNN_Model
            model = KNN_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'tabpfn':
            try:
                from base_models.tabpfn_model import TabPFN_Model
            except ModuleNotFoundError:
                from models.base_models.tabpfn_model import TabPFN_Model
            model = TabPFN_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'catboost':
            try:
                from base_models.catboost_model import CatBoost_Model
            except ModuleNotFoundError:
                from models.base_models.catboost_model import CatBoost_Model
            model = CatBoost_Model(metadata, input_cfg=config, seed=seed)
        elif model_name == 'xgb':
            try:
                from base_models.xgb_model import XGB_Model
            except ModuleNotFoundError:
                from models.base_models.xgb_model import XGB_Model
            model = XGB_Model(metadata, input_cfg=config, seed=seed)
        else:
            raise ValueError('Unknown model name was given.')
        return model

    return get_model(model_name, config)
